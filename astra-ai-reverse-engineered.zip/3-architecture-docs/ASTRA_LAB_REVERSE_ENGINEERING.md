# Technical Reverse-Engineering Report: `app.astra-ai.co/en-US/lab`

**Target:** `https://app.astra-ai.co/en-US/lab` and public child routes (`/en-US/lab/human-body-3d`, `/en-US/lab/solar-system`, `/en-US/lab/earth-interior`, `/en-US/lab/plant-cell-3d`, `/en-US/lab/geometry-3d`, `/en-US/lab/colosseum`)  
**Tooling:** REA (`rea-agents@6.9.0`, `C:\Dev\H-PATH\B1-L1\3D-L1\rea`) + passive headless Chromium network/chunk capture (`playwright-core`, no auth/paywall/anti-bot bypass) + direct static AST/source inspection of public Next.js chunks.  
**Sidecar Artifact Check:** `C:\Users\NSR.AS\Desktop\Web app (click through the pages)-html.zip` (unzipped to scratch; verified unrelated **Pharmacy Stock App** `<x-dc>`/`dc-runtime` UI mockup — documented separately below).

---

## 1. Evidence Provenance & Methodology (Including Tooling Observations)

1. **Public Route & Dynamic Chunk Capture (Passive Only)**
   - Fetched `https://app.astra-ai.co/en-US/lab` (HTTP 200, `"serverIsSignedIn":false`, `"view":"landing"`, `458,863` bytes).
   - Verified public HTTP 200 guest access on `/en-US/lab/human-body-3d`, `/en-US/lab/solar-system`, `/en-US/lab/earth-interior`, `/en-US/lab/plant-cell-3d`, `/en-US/lab/geometry-3d`, and `/en-US/lab/colosseum`.
   - Captured **49** initial landing chunks (47 `.js`, 2 `.css`), **11** SSR route chunks, and **89** runtime dynamic chunks + **5** 3D data/model assets (`atlas.json` male & female, `heart.29310af0ce2c.glb`, `lungs.e30cbb6cfb43.glb`, `plant_cell.glb`) into scratch directories.
2. **REA (`rea-agents@6.9.0`) Execution Notes on Windows + Node `v26.13.0`**
   - Initial `npm run build:cached` inside `./rea` failed under Node `v26.13.0` because `rea/scripts/lib/verifier-source-loader.mjs` line 98 calls `stripTypeScriptTypes(..., { mode: "transform", sourceMap: true })`, which Node 26 dropped (`ERR_INVALID_ARG_VALUE: The property 'options.mode' must be one of: 'strip'`; `.nvmrc` pins `24.22.1`). Direct `npm run compile` built `rea/dist/` with exit code 0, and `node rea/scripts/rea.mjs --help` (`rea@6.9.0`) succeeded.
   - First `rea analyze-javascript-application` run failed on file `1/47` because Git checkouts omit `native/windows/build/manifest.json` and `native/windows/build/rea-windows-x64.node` (`ENOENT`). Following `rea/native/windows/README.md`, both files were restored verbatim from `rea-agents@6.9.0`'s published npm tarball.
   - Second `rea analyze-javascript-application` run across all 47 landing chunks completed (`astra-rea-evidence-v2.json`, `202,363,866` bytes, Evidence ID `ev_cdc4baf72c39f5dce8a7707d787bec28060a3b2c154d8fcc5c7dacdf29af2e49`, 46/47 complete; `_next/static/immutable/chunks/3y82jtxkxhd6-.js` hit the default `1024 MiB` V8 worker heap ceiling).
   - Targeted `rea analyze-javascript-application --max-heap-mb 2048` across **14 core 3D/router/state chunks** (`rea-3d-target/`) completed with `0` application unknowns (`rea-3d-evidence.json`, `199,526,187` bytes, Evidence ID `ev_e3a235be4e3cdf9a5847564ebff7b77650a847cf4d313d891265944dd0d3457d`), verified via `rea inspect-analysis-view` (`kind: "summary"`, Evidence ID `ev_ba645c20f23074a8961cadac752e518a5e8d7cdfc2bb99ccc5f0d4e53ecf1c5a`, `312/312` examined items within view).
   - `rea audit-release-exposure` on `2624bxweegwgm.js` (Evidence ID `ev_0e084a3faac079ccd4c84de64ad4cab4d0b1cbf985843e0ad431b607a8a92c72`) reported `exposed: 0`, confirming production chunks ship without inline source maps or `.pdb`/source leaks.
   - `rea list-browser-targets` against Playwright-launched headless Chrome failed with `invalid_endpoint_response` (due to Playwright's pipe/flags overriding raw HTTP `/json` discovery), so dynamic chunks and UI screenshots were captured directly via `playwright-core` responses and analyzed statically with REA + Node.

---

## 2. Verified Architecture Findings

### A. Frontend Framework, Routing & State Management

#### Direct Observations
- **Next.js App Router + Turbopack + React 19:**
  - Chunks are served under `/_next/static/immutable/chunks/` with bootstrap `turbopack-0l1ukkt8h7dio.js` and React Server Component payloads (`self.__next_f.push(...)` seen in `lab.html` and `human-body-3d.html`).
  - Observed runtime React version string `19.3.0-canary-278794d7-20261002` in `2efincrrx3f56.js` and `3y82jtxkxhd6-.js`.
- **Modular Multi-Lab Router (`3tokhd22_kj2c.js` & `2-lh6m3h2s7cn.js`):**
  - Central slug map `j` dynamically imports **89** independent lab modules (`"human-body-3d": () => t.A(7634847).then(t => t.HumanBody3DPage)`, `"plant-cell-3d": () => t.A(7534826).then(t => t.PlantCell3DPage)`, `"solar-system": () => t.A(2305366).then(t => t.SolarSystemPage)`, `"earth-interior"`, `"periodic-table-3d"`, `"geometry-3d"`, `"world-landmarks"`, `"colosseum"`, `"race-garage"`, `"bridge-workshop"`, `"rocket-workshop"`, etc.).
  - Wrapped via `Object.fromEntries(r.u.map(slug => [slug, k.f(j[slug])]))` so the host shell can `.preload()` individual labs on demand.
  - **Pre-mount Capability Gatekeeper (`3tokhd22_kj2c.js`, `3rt0his0w_r--.js`):** Each lab entry carries metadata (`subject`, `kind`, `requiresWebGL`, `desktopOnly`, `addedAt`, `featuredOrder`); **22** catalog entries specify `requiresWebGL: true`. Before loading the lazy 3D chunk, a small state machine resolves `"loading" | "desktopOnly" | "unsupported" | "ready"` using WebGL capability detection (`x.E()`) and responsive viewport detection, rendering dedicated fallback UI when WebGL is missing, while using a `MutationObserver` on `[data-lab-app]` watching `[data-lab-loading], [aria-busy="true"]` to mark readiness telemetry.
- **State, API & Client Stores:**
  - **tRPC** (`3y82jtxkxhd6-.js`, `28gswl2_t-9-y.js`, `34-xd39z33pqi.js`, `3s8v8drazkjtv.js`) + dehydrated React Query state (`[["lab","getViewCounts"]]` seen in `rsc_decoded.txt` line 308; live request `/api/trpc/lab.leaderboard.dailySummary` observed in Playwright network log).
  - **Zustand** (`3dd_rxz1gz8nu.js`, `3mutxfja3258p.js`) present alongside local React `useState` / `useRef` refs synchronized inside `requestAnimationFrame` loops (`2624bxweegwgm.js`, `253b31r5uxxgj.js`).
  - Telemetry / external services observed: Sentry (`sentry.javascript.nextjs/10.76.2`), Singular WebSDK, Google Tag, KaTeX (`2tv0eo-705vyz.js`), and CDN asset hosts (`cdn.astra-ai.co`, `pub-52ddbfade8b641de80810e91dd746ae0.r2.dev`).

#### Inferences
- Because every lab is registered through a single metadata + lazy-import registry (`3rt0his0w_r--.js` + `3tokhd22_kj2c.js`), new labs can be shipped cleanly without bloating the catalog shell bundle (`49` landing chunks stay free of Three.js geometry until a WebGL lab mounts or preloads).

---

### B. 3D Rendering Stack, Lighting, Shaders & Color Pipeline

#### Direct Observations
- **Engine & Integration Pattern (`1grst_pqnop-f.js`, `2vx993uegjzm8.js`, `0fru45piknwam.js`, `2624bxweegwgm.js`, `253b31r5uxxgj.js`, `21mev0tqvz7vb.js`, `3hwdol1-6xne0.js`):**
  - Uses **Three.js `r185`** (`"185"` string constant in `1grst_pqnop-f.js`).
  - Rather than `@react-three/fiber`, all four inspected 3D simulations mount **vanilla `THREE.WebGLRenderer`** imperatively inside React `useEffect` hooks with deterministic cleanup (aborting fetches, cancelling `requestAnimationFrame`, disconnecting `ResizeObserver`, disposing geometries/materials/textures/PMREM/controls).
- **Renderer Calibration & Color Management (`2624bxweegwgm.js`, `253b31r5uxxgj.js`, `21mev0tqvz7vb.js`):**
  - `renderer.outputColorSpace = THREE.SRGBColorSpace` (`am.nj`)
  - `renderer.toneMapping = THREE.ACESFilmicToneMapping` (`am.c2`)
  - `renderer.toneMappingExposure`: `1.0` (Full-body atlas), `1.05` (Organ specimen & Solar System), `1.1` (Cell 3D)
  - `renderer.setPixelRatio(Math.min(window.devicePixelRatio, ...))` (capped dynamically for mobile / specimen viewer e.g. `1.75`, adaptive on resize `r.clientWidth < 768 || r.clientHeight < 600`)
  - Canvas created with `alpha: true, powerPreference: 'high-performance'`, transparent clear (`setClearColor(..., 0)`) letting the matte charcoal CSS backdrop show through cleanly.
- **Procedural Studio IBL & Multi-Light Rig (`2624bxweegwgm.js`, `2gd7ql1izcwiy.js`):**
  - Human Body Atlas generates neutral PBR image-based lighting at startup using `PMREMGenerator` + `RoomEnvironment` (`sigma = 0.04`), sets `scene.environment = pmremTarget.texture`, `scene.environmentIntensity = 0.35`, and immediately disposes the temporary `RoomEnvironment` and `PMREMGenerator`.
  - Lights in Atlas (`2624bxweegwgm.js` + `2gd7ql1izcwiy.js`):
    - `HemisphereLight(0xffffff, 0xa7acb2, 0.8)`
    - Warm Key `DirectionalLight(0xfffaf4, 1.6)` at `[-2, 4, 3]`
    - Cool Rim `DirectionalLight(0xe9f0ff, 1.0)` at `[2, 2, -3]`
  - Specimen Studio Rig (`heart`/`brain`/`lungs` close-up GLB viewer):
    - `HemisphereLight(0xe7f0ff, 0x4d3c38, 1.4)` + Key `DirectionalLight(0xffffff, 2.2)` at `[3, 4, 4]` + Rim `DirectionalLight(0xb7e3ff, 1.0)` at `[-4, 2, -2]` + Warm Under-fill `DirectionalLight(0xffd8b8, 0.85)` at `[0, -3, 1.4]`.
  - Material clamping on external GLB specimens: `roughness` clamped to `[0.42, 0.68]`, `metalness = 0`, `envMapIntensity = 0.6` to avoid greasy/plastic highlights.
- **Custom Shader Injection (`onBeforeCompile` in `2624bxweegwgm.js`):**
  - Instead of assigning 700–2,235 unique materials, Astra creates **one solid and one ghost `MeshStandardMaterial` per anatomical system** (`metalness: 0.08`, `roughness: 0.53`, ghost uses `DoubleSide`, `transparent: true`, `depthWrite: false`, `forceSinglePass: true`) with `customProgramCacheKey`.
  - State is packed into **two `DataTexture` lookup textures** (`width = ceilPowerOfTwo(parts.length)`, height `1`):
    - `partState` (`FloatType`, `RGBA`): `rgb` = per-part explode translation offset `[dx, dy, dz]`, `a` = per-part opacity/visibility (`0..1`).
    - `selectionState` (`UnsignedByteType`, `RGBA`): `r` = selection mask, `g` = female-sex morph membership.
  - Vertex shader reads `attribute float partIndex`, computes `stateUv = vec2((partIndex + 0.5) / stateWidth, 0.5)`, applies optional female shape warp (`if (sexMix > 0.0) transformed += warpAt(position) * sexMix;`) and explode offset (`transformed += state.xyz;`).
  - Fragment shader discards invisible or mismatched pass fragments in `#include <clipping_planes_fragment>` (`partVisible < 0.002 || (ghost ? partVisible >= 0.995 : partVisible < 0.995)`) and tints selection in `#include <color_fragment>` (`mix(diffuseColor.rgb, vec3(0.42, 0.52, 0.95), partSelected * 0.28)`).
  - Exploded-view guide dots (`PointsMaterial`) inject a circular SDF disc discard in fragment (`if (distance(gl_PointCoord, vec2(0.5)) > 0.5) discard;`).
  - No `EffectComposer` / multisampled post-processing pass was observed in the captured chunks (`HumanBody3D`, `Cell 3D`, `EarthInterior`, `SolarSystem`); glow effects in `SolarSystem` use radial canvas sprite textures (`CanvasTexture`).

#### Inferences
- Merging hundreds of sub-parts per system and driving explode offsets, fade/X-ray ghost transitions, and selection highlights through `DataTexture` uniforms dramatically cuts draw calls and eliminates CPU geometry reallocation during slider drags or animations.

---

### C. 3D Asset & Model Pipeline

#### Direct Observations
- **Streaming Binary Chunked Atlas (`atlas.json` + `/models/body-N.bin.gz`):**
  - `https://cdn.astra-ai.co/web/labs/human-body-3d/atlas/2962b934dfb6/atlas.json` (`1,352,155` bytes, `BodyParts3D 4.0`, `"optimized": { "method": "meshoptimizer quadric simplification" }`) indexes **2,235** parts, **3,423** FMA concepts, reduced from `6,681,030` source triangles to `2,292,132` triangles across **36** gzip-compressed binary chunks (`/models/body-0.bin.gz` ~`402,605` B gzip / `2,039,224` B raw).
  - Vertex buffers use compact stride packing: `Float32Array` positions, **quantized normalized `Int16Array` normals**, `Uint32Array` indices, plus precomputed AABB `bounds` per part.
  - Priority download queue limits concurrent chunk fetches (`2` during initial visible boot -> `6` for background chunks) with exponential backoff retry (`min(60000, 5000 * 2**(attempt-1))`), `AbortController` cleanup, and `bufferAttribute.onUpload(() => { array = array.slice(0, 0); })` to free CPU RAM immediately after GPU upload!
- **Draco & Meshopt GLB Specimens (`328q9g6xl9kyk.js`, `253b31r5uxxgj.js`, `2624bxweegwgm.js`):**
  - `GLTFLoader` paired with `MeshoptDecoder` and `DRACOLoader` loads standalone `.glb` hero assets (e.g., `heart.29310af0ce2c.glb` `397,824` B, `lungs.e30cbb6cfb43.glb` `342,060` B, `plant_cell.glb` `1,771,636` B).
- **Procedural & Hybrid Textures (`21mev0tqvz7vb.js`, `3hwdol1-6xne0.js`):**
  - `SolarSystemPage` blends CDN `.webp` maps (`moon.webp`, `earth-night.webp`, `starmap.webp`) with deterministic PRNG-seeded `CanvasTexture` generators (`2048x1024` crater/surface maps, `64x64` radial gradient glow sprites).

---

### D. Interaction Mechanics & Simulation Control

#### Direct Observations
- **Camera & OrbitControls (`2624bxweegwgm.js`, `253b31r5uxxgj.js`, `3hwdol1-6xne0.js`):**
  - Telephoto framing (`PerspectiveCamera(34, ...)` in HumanBody3D, `35°` in Cell 3D) minimizes perspective distortion on anatomical/biological specimens.
  - `OrbitControls`: `enableDamping = true`, `dampingFactor = 0.085` (Atlas) / `0.08` (Cell/Earth/Specimen), `zoomToCursor = true`, `maxPolarAngle = 0.96 * Math.PI`, explicit `minDistance`/`maxDistance`.
  - **Spherical Fly-To Focus + Auto-Framing:** Camera transitions compute visible bounding box (`Box3`), fit distance via `halfExtent / sin(fov/2) * margin` (`1.14` body, `1.4` partial focus, `1.65` isolate), and interpolate smoothly using **shortest-angle spherical delta** (`Math.atan2(Math.sin(dTheta), Math.cos(dTheta))`) + exponential damping (`1 - Math.exp(-9 * dt)`), immediately cancelling (`U = false`) if the user presses or zooms (`pointerdown` / `wheel`).
- **Two-Stage Explode ("Spread structures apart") & Dynamic Pointer Mapping (`2624bxweegwgm.js`):**
  - From `0..0.45`, systems expand radially along cylindrical angular vectors (`sin/cos` around system index angle) + vertical dispersion.
  - Above `0.45..1.0`, parts morph smoothly into a **sorted aspect-aware 2D shelf packing layout** (`width/height` cell packing), and above `0.8`, left-drag / 1-finger touch automatically switches from `ROTATE` to `PAN` so users can inspect spread-out parts like an interactive specimen tray!
- **AABB-Culled + Opacity-Prioritized Raycasting & Throttled Hover (`2624bxweegwgm.js`):**
  - Clicks distinguish drags from taps via pointer distance thresholds (`5px` desktop, `12px` touch).
  - Raycasting tests `ray.intersectBox(bbox)` per visible part before running mesh `intersectObject`, then splits hits into `solid (opacity >= 0.15)` vs `faded (opacity < 0.15)` so users click through ghosted ribs/muscles straight to deep solid organs!
  - Hover picking runs only when `!e.buttons` and `!touch`, throttled to `80ms`.
- **On-Demand Render Scheduling:** Renders frames only when flagged dirty (`d = true` on control change, camera fly-to, state update, resize, or `autoRotate`), saving GPU/battery when idle.
- **Keyboard & Accessibility Controls:** Canvas supports `tabIndex={0}`, `role="group"`, arrow-key orbit (or Shift+Arrow pan), `+`/`-` zoom, `Home` reset view, and `Enter` center-reticle pick.

---

### E. UI/UX Layout Patterns & Visual Tokens

#### Direct Observations
- **Unified Multi-Lab App Chrome (Observed visually across `human-body-3d.png`, `solar-system.png`, `earth-interior.png`, `plant-cell-3d.png` & DOM report):**
  - Top bar (`<-` back, lab icon, concise title + `SUBJECT · SIMULATION` subtitle, right utility pills `Ask the tutor`, `Rate`, `...`).
  - Left/Right translucent dark cards (`#0f0f0f` `--radar-panel`, `#181818` `--radar-glass-fill` with multi-stop hairline top specular gradient in `2vlx9tzjvn79q.css`) leaving the central 3D viewport unobstructed.
  - **Bottom Floating Control Pill:** Houses camera angle presets (`Front | Back | Side | Perspective`), Sex morph switch, Explode slider (`0%` with reset), Zoom `-`/`+`, and Tour/Labels toggles.
  - **In-Canvas Micro-HUD:** Top-left live status badge (`Visible structures: 739` or `magnified ×700 · 10 µm` scale bar), bottom-right anatomical **S/A/I/L/R orientation rosette**, clickable `Hotspot` 3D pins, and Guided Exploration / Quiz stepper (`Find it` / `Name it` with `PART X OF Y < >`).
- **Light & Dark Design Tokens (`2vlx9tzjvn79q.css`):** Define dual-mode CSS custom properties (`--radar-panel: #0f0f0f` vs `#f3f1ed`, `--radar-track`, `--radar-glass-fill`, `--radar-glass-shadow`) alongside anatomical system hex colors in `2gd7ql1izcwiy.js`.

---

## 3. Desktop Zip Inspection Note

- `C:\Users\NSR.AS\Desktop\Web app (click through the pages)-html.zip` was extracted and inspected (`README.md`, `Main.dc.html`, `support.js`, `vendor/react*.js`).
- **Direct observation:** It is an offline exported **Pharmacy Stock App** click-through prototype using `<x-dc>` / `dc-runtime`, **not** part of `app.astra-ai.co`. Its CSS patterns (token-driven `--g1`/`--g2` depth layering, sliding nav indicators, and `prefers-reduced-motion` support) serve solely as an auxiliary CSS reference.

---

## 4. Actionable Transferable Patterns for `OsteoMyo 3D`

| # | Observed Astra Lab Pattern | Concrete Upgrade Opportunity in `OsteoMyo 3D` |
|---|-----------------------------|-----------------------------------------------|
| 1 | `PMREMGenerator` + `RoomEnvironment` IBL + balanced Key/Rim/Fill | Replace un-environment-mapped lighting with baked studio IBL (`RoomEnvironment`) + distinct Studio vs Clinical lighting presets & `SRGBColorSpace` procedural textures |
| 2 | Zero per-frame geometry allocation + dirty/visibility gating | Eliminate per-frame `TubeGeometry` recreation for ALL 92 muscles in `rebuildMuscleGeometries`; rebuild only visible muscles & pause RAF loop when `document.hidden` |
| 3 | Cancel fly-to on user pointer/wheel input + spherical shortest-arc tween + `zoomToCursor` | Hook `controls.addEventListener('start', ...)` to cancel `cameraAnim`, adopt smooth exponential frame-rate independent spherical damping + `36°–38°` telephoto FOV, and cancel raycasting while dragging |
| 4 | AABB pre-culling + opacity-tiered picking + drag threshold + 80ms hover throttle | Check bounding boxes / throttle `pointermove` hover (`~60-80ms`) & enforce click-vs-drag threshold (`5px`) so orbiting never misfires selection |
| 5 | Floating bottom camera/explode dock + panel collapse / HUD zen toggle + modular multi-lab shell | Upgrade `OsteoMyo 3D` HUD with floating bottom camera/quick-controls dock, collapsible inspector/catalog drawers (`H` zen mode), FPS/draw telemetry pill, keyboard `1–8` camera shortcuts, and a clean `LabRegistry` structure |

---

## 5. Explicit Unknowns

- Authenticated-only server endpoints (e.g., `/en-US/lab/human-body-3d` AI tutor chat streaming when signed in) and private tRPC mutations were **not** inspected, respecting authentication boundaries.
- Non-captured lab slugs (e.g., `world-landmarks`, `colosseum`, `race-garage`) likely follow either the same vanilla Three.js + GLB/procedural pattern or Canvas2D; their individual chunks were not downloaded because only 5 routes were loaded passively.
- Original unminified TypeScript symbol names and source comments are stripped (confirmed by `rea audit-release-exposure` returning zero embedded source maps).
